import React from "react";
import ReactDOMClient from "react-dom/client";
import { Blog } from "./screens/Blog";

const app = document.getElementById("app");
const root = ReactDOMClient.createRoot(app);
root.render(<Blog />);
